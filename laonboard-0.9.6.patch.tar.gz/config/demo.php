<?php

// 사용자 데모 관리자 로그인 데모 정보
return [
    'email' => '',
    'password' => '',
];
