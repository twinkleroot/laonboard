
1.	$ git clone https://github.com/gnuboard/laratest.git 폴더명(ex: laonboard) ( www 에서) <br>
<br>
2.	Shell<br>
$ mv www www2 ( ~ 에서)<br>
$ ln -s www2/laonboard/public www ( ~ 에서)<br>
<br>
3.	설치하려는 홈페이지로 브라우저에서 접속해서 설치를 진행한다.<br>
<br>
<br>
## License
<br>
The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).
