<?php

return [
    'name' => 'PopularSearches',
    'del' => 60,
];
