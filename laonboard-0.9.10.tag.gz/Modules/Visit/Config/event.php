<?php

return [
    // 접속자 현황을 추가한다.
    'footerUp' => [
        'addVisitStatus' => [
            'module' => 'Visit',
            'priority' => 1,
            'use' => 1,
            'description' => '접속자 현황을 추가',
        ],
    ],
];
