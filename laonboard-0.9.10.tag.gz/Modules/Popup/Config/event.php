<?php

return [
    'headerUp' => [
        'addPopup' => [
            'module' => 'Popup',
            'priority' => 1,
            'use' => 1,
            'description' => '메인 헤더에 팝업 추가',
        ],
    ],
];
