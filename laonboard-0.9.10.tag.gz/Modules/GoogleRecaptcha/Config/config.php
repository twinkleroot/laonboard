<?php

return [
    'name' => 'GoogleRecaptcha'
];
