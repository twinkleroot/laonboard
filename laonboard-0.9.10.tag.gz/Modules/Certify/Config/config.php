<?php

return [
    'name' => 'Certify',
    'certUse' => 0,
    'certIpin' => '',
    'certHp' => '',
    'certKcbCd' => '',
    'certLimit' => 2,
    'certReq' => 0,
];
