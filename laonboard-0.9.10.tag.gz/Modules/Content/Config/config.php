<?php

return [
    'name' => 'Content'
];
