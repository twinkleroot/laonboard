<div class="container">
    <p>{{ $subject }}</p>
    <p><img src="{{ $imgPath }}" /></p>
    <p>{{ $content }}</p>
</div>
