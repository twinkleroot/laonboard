<?php

return [
    'mainContents' => [
        'addBanner' => [
            'module' => 'CustomMain',
            'priority' => 1,
            'use' => 0,
            'description' => '배너 추가',
        ],
    ],
];
