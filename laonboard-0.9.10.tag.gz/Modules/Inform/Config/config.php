<?php

return [
    'name' => 'Inform',
    'del' => 60
];
